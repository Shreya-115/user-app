BLOOD DONATION PLATFORM
A blood donation platform connects donors with blood banks or hospitals to collect and distribute blood. 
It helps schedule donations, track history, and ensure a safe blood supply for patients in need.
Prequisites
• Java 22
• Apache  Maven
•MySQL

